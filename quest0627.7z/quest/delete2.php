<?php
extract($_REQUEST);
include('connect.php');
mysqli_query($db, "delete from art where id='$del'"); //刪除sub裡id欄位的資料
header("Location:quest_main.php");
?>