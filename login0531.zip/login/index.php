<?php 
include 'config.php';

session_start();
error_reporting(0);

if (isset($_SESSION['id'])) {
    header("Location: login_main.php");
}
if (isset($_POST['submit'])){
	$email = $_POST['email'];
	$password = md5($_POST['password']);
	$sql = "SELECT email,`password`,`login`,id FROM users WHERE email='$email'";
	$result = mysqli_query($conn, $sql);
	$row = mysqli_fetch_assoc($result);
	if ($result->num_rows > 0 && $row['password']==$password && $row['login']<3) {
		mysqli_query($conn,"UPDATE users SET `login`= 0 WHERE email='$email'");
		$_SESSION['id'] = $row['id'];
		$_SESSION['kkey'] = number();
		setcookie("user",password_hash($_SESSION['kkey'],PASSWORD_DEFAULT),time()+3600*24);
		header("Location: login_main.php");
	}else if($result->num_rows > 0 && $row['password']==$password && $row['login']>=3 && isset($_POST['notroabe'])){
		mysqli_query($conn,"UPDATE users SET `login`= 0 WHERE email='$email'");
		$_SESSION['id'] = $row['id'];
		$_POST['notroabe']="";
		$_SESSION['kkey'] = number();
		setcookie("user",password_hash($_SESSION['kkey'],PASSWORD_DEFAULT),time()+3600*24);
		header("Location: login_main.php");
	}else if($result->num_rows > 0  && $row['login']>=3 && empty($_POST['notroabe'])){
		echo "<script>alert('請勾選我不是機器人。')</script>";
	}
	else {
		$count=$row['login']+1;
		mysqli_query($conn,"UPDATE users SET `login`= $count WHERE email='$email'");
		echo "<script>alert('糟糕!信箱或密碼錯誤。')</script>";
	}
}
if($row['login']>=2){
	$msg='<input type="checkbox" name="notroabe" value="notroabe">我不是機器人';
}else{
	$msg="";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

		<link rel="stylesheet" type="text/css" href="style.css">

		<title>朝陽公司</title>
</head>
<body>
	<div class="container">
		<form action="" method="POST" class="login-email">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;">登入</p>
			<div class="input-group">
				<input type="email" placeholder="信箱" id="em" name="email" value="<?php echo $email; ?>" required>
			</div>
			<div class="input-group">
				<input type="password" placeholder="密碼" name="password" value="<?php echo $_POST['password']; ?>" required>
			</div>
			<div class="input-group">
				<button name="submit" class="btn" id="btn">登入</button><br>
			</div>
			<p><?php echo $msg; ?></p><br>
			<p class="login-register-text">忘記密碼? <a href="forgot.php">點這邊找回</a></p>
			<p class="login-register-text">還沒有帳號? <a href="register.php">點這邊註冊</a></p>
			<p class="login-register-text">回首頁? <a href="../main/index.php">回首頁</a></p>
		</form>
	</div>
</body>
</html>